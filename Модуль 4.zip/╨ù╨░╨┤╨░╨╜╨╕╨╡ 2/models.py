from django.db import models

class Client(models.Model):
    id = models.IntegerField('id', primary_key=True)
    fio = models.CharField(max_length=255)
    phone = models.CharField(max_length=20)

class Orders(models.Model):
    id = models.IntegerField('id', primary_key=True)
    title = models.CharField(max_length=255)
    description = models.CharField(max_length=255)
    client_id = models.ForeignKey(Client, on_delete=models.PROTECT)
    adress = models.CharField(max_length=255)
    price = models.FloatField()
    created = models.DateTimeField()


class Documents(models.Model):
    id = models.IntegerField('id', primary_key=True)
    title = models.CharField(max_length=255)
    description = models.CharField(max_length=255)
    order_id = models.ForeignKey(Orders, on_delete=models.PROTECT)


class Smena(models.Model):
    id = models.IntegerField('id', primary_key=True)
    start_date = models.DateTimeField()
    end_date = models.DateTimeField()

class Administrator(models.Model):
    id = models.IntegerField('id', primary_key=True)
    fio = models.CharField(max_length=255)
    phone = models.CharField(max_length=20)
    login = models.CharField(max_length=255)
    password = models.CharField(max_length=255)
    banned = models.BooleanField()


class Urist(models.Model):
    id = models.IntegerField('id', primary_key=True)
    fio = models.CharField(max_length=255)
    phone = models.CharField(max_length=20)
    login = models.CharField(max_length=255)
    banned = models.BooleanField()
    password = models.CharField(max_length=255)
    smena_id = models.ForeignKey(Smena, on_delete=models.PROTECT)
    documents_id = models.ForeignKey(Documents, on_delete=models.PROTECT)

