INSERT INTO api_client (id, fio, phone) VALUES (1, 'Иванов Иван Иванович', '8999358677');
INSERT INTO api_client (id, fio, phone) VALUES (2, 'Иванов Иван Иванович', '89067156733');
INSERT INTO api_client (id, fio, phone) VALUES (3, 'Иванов Иван Иванович', '89024242414');
INSERT INTO api_client (id, fio, phone) VALUES (4, 'Иванов Иван Иванович', '89992424244');
INSERT INTO api_client (id, fio, phone) VALUES (5, 'Иванов Иван Иванович', '89934242245');
INSERT INTO api_client (id, fio, phone) VALUES (6, 'Иванов Иван Иванович', '89904422455');
INSERT INTO api_client (id, fio, phone) VALUES (7, 'Иванов Иван Иванович', '89242424252');
